/**
 * Created by Pkp on 5/15/2016.
 */

angular.module('issueTracker')
    .controller('dashboardCtrl',['$scope', '$window', 'httpService', '$routeParams', '$filter',
        '$location', function($scope, $window, httpService, $routeParams, $filter, $location) {

            $scope.initProcess = function(){
                $scope.enableList();
                $scope.loadEmpTable();
                $scope.loadIncidentsTable();
                $scope.loadChangesTable();
                $scope.loadRfiTable();
                $scope.populateChangeTile();
                $scope.populateIncidentTile();

            }

            $scope.loadIncidentsTable = function(){

                var url = "/api/dashboard/incidents";
                $scope.data = {};
                httpService.callRestApi(null, url, "GET")
                    .then(function(response){

                            $scope.data = response.data;

                    } ,
                    function(reason){

                        $location.path('/oops/');
                    });
            }
            $scope.loadEmpTable=function()
            {
                var url = "/api/user/get";
                $scope.data1 = {};
                httpService.callRestApi(null, url, "POST")
                    .then(function(response){
                        //console.log(response)
                        $scope.data1 = response.data;

                    } ,
                    function(reason){

                        $location.path('/oops/');
                    });
            }



            $scope.loadChangesTable = function(){

                var url = "/api/dashboard/changes";
                $scope.changes = {};
                httpService.callRestApi(null, url, "GET")
                    .then(function(response){


                        $scope.changes = response.data;

                    } ,
                    function(reason){

                        $location.path('/oops/');
                    });
            }

            $scope.loadRfiTable = function(){

                var url = "/api/dashboard/requests";
                $scope.rfi = {};
                httpService.callRestApi(null, url, "GET")
                    .then(function(response){


                        $scope.rfi = response.data;

                    } ,
                    function(reason){

                        $location.path('/oops/');
                    });
            }
            $scope.clearloc=function()
            {

            }
            $scope.enableList=function(){

                //$window.location.reload();
                var r=localStorage.getItem('role');
                $('#p1').text(localStorage.getItem('email'));
                $('#h1').text(localStorage.getItem('firstname'));
               // var a=localStorage.getItem('email');
                if(r==1)
                {
                    alert('This is supervisor login');
                    if (! localStorage.justOnce)
                    {
                        localStorage.setItem("justOnce", "true");
                        window.location.reload();

                    }
                    //$window.location.reload();
               //     $route.reload();

                    $('#list222').hide();
                    $('#list422').hide();
                    $('#list2').hide();
                    $('#list20').show();
                    $('#list3').hide();
                    $('#list30').hide();
                    $('#list4').hide();
                    $('#div61').show();
                    $('#div62').show();
                    $('#div63').show();

                   // $('#p1').text(localStorage.getItem('email'));
                }
                else if(r==2)
                {
                    if (! localStorage.justOnce)
                    {
                        localStorage.setItem("justOnce", "true");
                        window.location.reload();
                        alert('This is employee login');
                    }

                    $('#list3').hide();
                    $('#list422').hide();
                    $('#list2').hide();
                    $('#list4').hide();
                    $('#list30').hide();
                    $('#list20').hide();
                    $('#div11').show();
                    $('#div61').hide();
                    $('#div62').hide();
                    $('#div63').hide();
                }
                else
                {
                    if (! localStorage.justOnce)
                    {
                        localStorage.setItem("justOnce", "true");
                        window.location.reload();
                        alert('This is customer login');
                    }
                    $('#id1').hide();
                    $('#id2').hide();
                    $('#list1').show();
                    $('#list422').show();
                    $('#list3').show();
                    $('#list30').show();
                    $('#list20').hide();
                    $('#div11').show();
                    $('#list2').hide();
                    $('#b1').show();
                    $('#h1').show();
                    $('#list4').hide();
                    $('#list5').show();
                    $('#list222').hide();
                    $('#list6').show();
                    $('#list7').show();
                    $('#list8').show();
                    //$('#olist1').hide();
                    $('#list9').show();
                    $('#div1').show();
                    $('#div2').show();
                    $('#div3').show();
                    $('#div4').show();
                    $('#div5').show();
                    $('#div6').show();
                    $('#div7').show();
                    $('#div11').show();
                    $('#div61').show();
                    $('#div62').hide();
                    $('#div63').hide();
                    // $('#div6').hide();
                    //$('#div7').hide();
                    //$('#div8').hide();
                    // $('#div9').hide();
                    $('#btn1').show();

                }





            }

            $scope.populateIncidentTile = function(){

                var url = "/api/dashboard/incidents-month";
                httpService.callRestApi(null, url, "GET")
                    .then(function(response){

                        $scope.incidentCount = response.data.length;

                    } ,
                    function(reason){

                    });

            }

            $scope.populateChangeTile = function(){

                var url = "/api/dashboard/changes-month";
                httpService.callRestApi(null, url, "GET")
                    .then(function(response){

                        $scope.changeCount = response.data.length;

                    } ,
                    function(reason){

                    });

            }




        }]);
