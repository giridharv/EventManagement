/**
 * Created by Giridhar on 12/3/2016.
 */
/**

 */
angular.module('issueTracker')
    .controller('indexController',['$scope', '$window', 'httpService', '$routeParams', '$filter',
        '$location', function($scope, $window, httpService, $routeParams, $filter, $location){
            $scope.options = [];

            $scope.createIncident = function(incidentDetails){

                if(incidentDetails.incidentType && incidentDetails.application   && incidentDetails.priority ) {
                    $scope.submitButtonClass = true;
                    $scope.resetButtonClass = true;
                    var url = "/api/incident/create"
                    $("#loader").show();
                    httpService.callRestApi(incidentDetails, url, "POST")
                        .then(function(response){
                            $("#loader").hide();
                            $scope.incidentID = response.data.incidentID;
                            $("#success-alert").show();
                            $scope.createNewButtonClass = true;

                        } ,
                        function(reason){
                            $("#loader").hide();
                            $scope.errorMsg = reason;
                            $("#danger-alert").show();

                            $scope.createNewButtonClass = true;
                            console.log(reason);
                        });


                }else{

                    alert("Please fill out all fields");
                }


            }
            $scope.clearStore=function()
            {
                localStorage.removeItem('justOnce');
                localStorage.removeItem('justTwice');

                $location.path('/login/');
            }

            $scope.resetForm = function(){

                $window.location.reload();

            }
            $scope.options = [{
                name: 'Catering',
                value: false
            }, {
                name: 'Tables',
                value: false
            }, {
                name: 'Chairs',
                value: false
            }, {
                name: 'Table linens',
                value: false
            }, {
                name: 'Dinnerware/Chinaware',
                value: false
            }, {
                name: 'Entertainmen',
                value: false
            }];

            $scope.save = function()
            {

                var optionsCSV = '';

                $scope.options.forEach(function(option)
                {

                    if (option.value)
                    {

                        // If this is not the first item
                        if (optionsCSV) {
                            optionsCSV += ','
                        }
                        optionsCSV += option.name;

                    }

                })
                console.log(optionsCSV);
                alert(optionsCSV);
            };


            $scope.newIncident = function(){

                $window.location.reload();

            }



            $scope.getIncidentDetail = function(){
                $scope.isVisible = false;
                $scope.incId = $routeParams.incidentID;
                $("#loader").show();
                findIncidentById($scope.incId);

            }

            $scope.updateIncident = function(data){
                console.log(data);

                /* $("#loader").show();
                 $scope.newData = {};
                 $scope.newData.orderID = data.orderID;s
                 $scope.newData.incidentID = data.incidentID;
                 $scope.newData.orderTitle = data.orderTitle;
                 $scope.newData.eventDate = data.eventDate;
                 $scope.newData.releaseDate = data.releaseDate;
                 $scope.newData.eventTime = data.eventTime;
                 //$scope.newData.description = data.description;
                 $scope.newData.incidentType = data.incidentType;
                 $scope.newData.reportedBy = data.reportedBy;
                 $scope.newData.title = data.title;
                 $scope.newData.version = data.version;
                 $scope.newData.description = addUpdate(data.update, data.description);

                 var url = "/api/incident/update";

                 httpService.callRestApi( $scope.newData, url, "POST")
                 .then(function(response){
                 findIncidentById(response.data.incidentID);
                 $("#success-alert").show();



                 } ,
                 function(reason){
                 $("#loader").hide();
                 $scope.errorMsg = reason;
                 $("#danger-alert").show();

                 });


                 */
            }

            var  addUpdate = function(update, desc){
                var date = new Date();
                var updateDT = (date.getMonth()+1).toString() +"/"+ date.getDate().toString() +"/"+  date.getFullYear().toString() +"  "+  date.getHours().toString() +":"+ date.getMinutes().toString();
                var updateString = "------ Status : "+ $scope.newData.status+" | Last Updated by user at "+ updateDT + " ------" + "\n";
                desc = desc+ "\n" + updateString + update;

                return desc;
            }

            var findIncidentById = function(incId){

                var url = "/api/incident/new-incident";
                $scope.data = {};
                httpService.callRestApi({incidentID : incId}, url, "POST")
                    .then(function(response){
                        $("#loader").hide();
                        if(response.data.incidentID != undefined) {
                            $scope.isVisible = true;
                            if((response.data.status == 'Closed') || (response.data.status == 'Rejected')){
                                $scope.isClosed = true;
                            }

                            $scope.data = response.data;
                            $scope.data.reportedDate = $filter("date")(response.data.reportedDate, 'MM/dd/yyyy HH:mm:ss');
                            $scope.data.releaseDate = $filter("date")(response.data.releaseDate, 'yyyy-MM-dd');


                        }else{
                            $("#loader").hide();
                            $location.path('/damn-it/');
                        }


                    } ,
                    function(reason){
                        $("#loader").hide();
                        $location.path('/oops/');
                    });
            }


        }
    ]
);
