/**
 * Created by Giridhar on 10/15/2016.
 */
var mongoose = require('mongoose');

var itemSchema=mongoose.Schema({
    itemtype:{type:String},
    eventlocationsoffered:{type:String},
    chairs:{type:Number},
    tables:{type:Number},
    dinnerware:{type:String},
    tablelinens:{type:String},
    technicalequipment:{type:String},
    catering:{type:String},
    specialisedpersonnel:{type:String},
    emailId:{type:String},
    //itemvalue:{type:Number},
    itemavailability:{type:String},
    itemissueDate:{type:Date},
    itemavailableby:{type:Date},
    vendorname:{type:String}
});

var item = mongoose.model('item', itemSchema);


module.exports = item;
