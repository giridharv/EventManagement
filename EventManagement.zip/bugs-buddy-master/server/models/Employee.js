/**
 * Created by Giridhar on 12/6/2016.
 */
var mongoose = require('mongoose');
var newEmployeeSchema = mongoose.Schema({

    name:{type:String},
    address:{type:String},
    SSN:{type:String,unique:true},
    position: {type:String},
    salary:{type:String}
});
var employees = mongoose.model('employees', newEmployeeSchema);
module.exports = employees;