/**
 * Created by Giridhar on 10/16/2016.
 */

var mongoose = require('mongoose');
var userSchema = mongoose.Schema({
    role:{type:Number, default:0},
    firstname:{type:String},
    lastname:{type:String},
    email:{type:String,unique:true},
    phone: {type:String},
    address:{type:String},
    city:{type:String},
    state:{type:String},
    zip:{type:String},
    password1:{type:String},
    password:{type:String}





});
var users = mongoose.model('users', userSchema);
module.exports = users;