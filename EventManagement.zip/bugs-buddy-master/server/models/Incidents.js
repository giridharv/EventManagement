var mongoose = require('mongoose');

var incidentSchema = mongoose.Schema({
  incidentID: {type:String, unique:true},
  orderTitle:{type:String,unique:true},
  eventDate:{type:String,unique:true},
  equipment:{type:Array,default:[]},
  eventType:{type:Array,default:[]},
  supplies:{type:Array,default:[]},
  specialisedPersonnel:{type:Array, default: []},
  locationdesired:{type:String},
  eventTime:{type:String,unique:true},
  priority: {type:String},
  releaseDate: {type:Date, default: Date.now},
  description : {type : String}});



var Incident = mongoose.model('Incident', incidentSchema);


module.exports = Incident;