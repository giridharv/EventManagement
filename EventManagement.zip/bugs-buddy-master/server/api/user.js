/**
 * Created by Giridhar on 10/25/2016.
 */

var express = require('express');
var router = express.Router();
var userController = require('../controllers/login');
var registerController = require('../controllers/register');
var vendorController= require('../controllers/vendor');
var employeeController=require('../controllers/employee');

router.use(function(req, res, next) {

    next();
});

router.post('/login', function(req, res){

    userController.userInput(req.body, res);


});

router.post('/registration', function(req, res){

    registerController.onRegister(req.body, res);

});
router.post('/Employee', function(req, res){

    employeeController.createEmployee(req.body, res);

});
router.post('/get', function(req, res){

    employeeController.loadingTable(res);

});
router.post('/vendorregistration',function(req,res)
{
vendorController.onVendor(req.body,res);
})


module.exports = router;
