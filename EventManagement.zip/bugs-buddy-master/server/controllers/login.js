/**
 * Created by Giridhar on 10/25/2016.
 */

var users = require('../models/users');
var LoggedIn = require('mongoose').model('users');

exports.userInput = function(payLoad, res){


    LoggedIn.find({email:payLoad.email,password:payLoad.password}, function(err, data){

        var resObj = {};


        if(err){
            return res.status(500).json("Internal Server Error" + err);

        }
        if(data.length > 0){
            resObj.status = 200;
            resObj.data = data;
            res.status(200).json(resObj);
        }else{
            resObj.status = 401;
            resObj.data = "Authentication Failure";
            res.status(200).json(resObj);

        }
    });

}