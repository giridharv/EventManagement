/**
 * Created by Giridhar on 11/4/2016.
 */

var item= require('../models/Items');
var reqitem = require('mongoose').model('item');

exports.onVendor=function(payLoad,res)
{
    reqitem.find({emailId:payLoad.emailId}, function(err,data){

        var resObj = {};


        if(err){
            return res.status(500).json("Internal Server Error" + err);

        }
        if(data.length > 0)
        {
            resObj.status = 403;
            resObj.data = "user with same email id exists";
            return res.status(200).json(resObj);
        }
        else
        {
            reqitem.create(payLoad, function(err, data){
                if(err)
                {
                    return res.json(err.message);
                }
                resObj.status = 200;
                resObj.data = data;
               return res.status(200).json(resObj);
            })


        }
    });

}