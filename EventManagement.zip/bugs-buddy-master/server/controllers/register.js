/**
 * Created by Giridhar on 10/25/2016.
 */

var users = require('../models/users');
var regusers = require('mongoose').model('users');

exports.onRegister=function(payLoad,res)
{
       regusers.find({email:payLoad.email}, function(err,data){
        var resObj = {};


        if(err){
            return res.status(500).json("Internal Server Error" + err);

        }
        if(data.length > 0){
            resObj.status = 403;
            resObj.data = "user with same email id exists";
            return res.status(200).json(resObj);
        }else
        {
            regusers.create(payLoad, function(err, data){
                if(err)
                {
                    res.json("Internal Server error");
                }
                resObj.status = 200;
                resObj.data = data;
                res.status(200).json(resObj);
            })


        }
           });

}