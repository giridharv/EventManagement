/**
 * Created by Giridhar on 12/6/2016.
 */
var employees = require('../models/Employee');
var employee = require('mongoose').model('employees');

exports.createEmployee=function(payLoad,res)
{
    employee.find({name:payLoad.name}, function(err,data){

        var resObj = {};


        if(err){
            return res.status(500).json("Internal Server Error" + err);

        }
        if(data.length > 0){
            resObj.status = 403;
            resObj.data = "user with same name exists";
            return res.status(200).json(resObj);
        }else
        {
            employee.create(payLoad, function(err, data){
                if(err)
                {
                    res.json("Internal Server error");
                }
                resObj.status = 200;
                resObj.data = data;
                res.status(200).json(resObj);
            })


        }
    });

}



exports.loadingTable = function(res){

    employee.find()
        .exec(function(err, docs){
            if(err) return res.status(500).json("Internal Server Error");
            res.status(200).json(docs);
        }
    );
}